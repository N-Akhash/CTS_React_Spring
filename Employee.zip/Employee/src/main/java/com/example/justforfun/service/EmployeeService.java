package com.example.justforfun.service;

import java.util.List;

import com.example.justforfun.entity.Employee;

public interface EmployeeService {
	
	abstract String addEmployee(Employee employee);
	abstract String updateEmployee(Employee employee);
	abstract String deleteEmployee(int employeeId);
	abstract Employee getEmployeeById(int employeeId);
	abstract List<Employee> getAllEmployees();
	abstract List<Employee> getAllEmployeesBetweenSalary(int initialSalary,int finalSalary );
	abstract List<Employee> getAllEmployeeByDesignation(String employeeDesignation);

}
