package com.example.justforfun.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.justforfun.entity.Employee;


import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addEmployee(Employee employee) {
		entityManager.persist(employee);
		
		return "Employee added Successfully";
	}

	@Override
	public String updateEmployee(Employee employee) {
		entityManager.merge(employee);
		
		return "Employee updated Successfully";
	}

	@Override
	public String deleteEmployee(int employeeId) {
		entityManager.remove(getEmployeeById(employeeId));
		return "Employee deleted successfully";
	}


	@Override
	public Employee getEmployeeById(int employeeId) {
		return entityManager.find(Employee.class,employeeId);
	}

	@Override
	public List<Employee> getAllEmployees() {
		TypedQuery<Employee> employee = entityManager.createQuery("select e from Employee e",Employee.class);
		
		return employee.getResultList();
	}

	@Override
	public List<Employee> getAllEmployeesBetweenSalary(int initialSalary, int finalSalary) {
		TypedQuery<Employee> employee = entityManager.createQuery("select e from Employee e where e.employeeSalary between ?1 and ?2",Employee.class);
		employee.setParameter(1, initialSalary);
		employee.setParameter(2, finalSalary);
		return employee.getResultList();
	}

	@Override
	public List<Employee> getAllEmployeeByDesignation(String employeeDesignation) {
		TypedQuery<Employee> employee = entityManager.createQuery("select e from Employee e where e.employeedesignation=?1",Employee.class);
		employee.setParameter(1, employeeDesignation);
		return employee.getResultList();
	}

}
