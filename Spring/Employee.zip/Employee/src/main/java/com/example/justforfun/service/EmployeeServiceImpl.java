package com.example.justforfun.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.justforfun.dao.EmployeeDao;
import com.example.justforfun.entity.Employee;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeDao dao;

	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return dao.addEmployee(employee);
	}

	@Override
	public String updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return dao.updateEmployee(employee);
	}

	@Override
	public String deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(employeeId);
	}

	@Override
	public Employee getEmployeeById(int employeeId) {
		// TODO Auto-generated method stub
		return dao.getEmployeeById(employeeId);
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return dao.getAllEmployees();
	}

	@Override
	public List<Employee> getAllEmployeesBetweenSalary(int initialSalary, int finalSalary) {
		// TODO Auto-generated method stub
		return dao.getAllEmployeesBetweenSalary(initialSalary, finalSalary);
	}

	@Override
	public List<Employee> getAllEmployeeByDesignation(String employeeDesignation) {
		// TODO Auto-generated method stub
		return dao.getAllEmployeeByDesignation(employeeDesignation);
	}

}
