package com.example.justforfun.dao;

import java.util.List;

import org.hibernate.sql.results.jdbc.internal.JdbcValuesMappingProducerProviderStandard;
import org.springframework.stereotype.Repository;

import com.example.justforfun.entity.Product;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository
public class ProductDaoImpl implements ProductDao {
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		
		return "Product Saved Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		
		entityManager.merge(product);
		
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		
		entityManager.remove(getProductById(productId));
		
		return "Product deleted Successfully";
	}

	@Override
	public Product getProductById(int productId) {
		
		
		return entityManager.find(Product.class,productId);
	}

	@Override
	public List<Product> getAllProducts() {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p",Product.class);
		
		return products.getResultList();
	}

	@Override
	public List<Product> getAllProductsBetweenPrices(int initialPrice,int finalPrice) {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p where p.productPrice between ?1 and ?2",Product.class);
		products.setParameter(1, initialPrice);
		products.setParameter(2, finalPrice);
		return products.getResultList();
		

	}

	@Override
	public List<Product> getAllProductByCategory(String productCategory) {
		TypedQuery<Product> products = entityManager.createQuery("select p from Product p where p.productCategory=?1",Product.class);
		products.setParameter(1, productCategory);
		return products.getResultList();
		




	}

}
