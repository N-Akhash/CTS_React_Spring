package com.example.justforfun.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.justforfun.dao.ProductDao;
import com.example.justforfun.entity.Product;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class  ProductServiceImpl  implements ProductService{
	@Autowired
	ProductDao dao;

	@Override
	public String addProduct(Product product) {
		// TODO Auto-generated method stub
		return dao.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {
		// TODO Auto-generated method stub
		return dao.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return dao.deleteProduct(productId);
	}

	@Override
	public Product getProductById(int productId) {
		// TODO Auto-generated method stub
		return dao.getProductById(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return dao.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsBetweenPrices(int initialPrice, int finalPrice) {
		// TODO Auto-generated method stub
		return dao.getAllProductsBetweenPrices(initialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductByCategory(String productCategory) {
		// TODO Auto-generated method stub
		return dao.getAllProductByCategory(productCategory);
	}
	
	

	

}
