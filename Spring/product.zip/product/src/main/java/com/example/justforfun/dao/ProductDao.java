package com.example.justforfun.dao;
import java.util.List;
import com.example.justforfun.entity.Product;
public interface ProductDao {
	
	abstract String addProduct(Product product);
	abstract String updateProduct(Product product);
	abstract String deleteProduct(int productId);
	abstract Product getProductById(int productId);
	abstract List<Product> getAllProducts();
	abstract List<Product> getAllProductsBetweenPrices(int initialPrice,int finalPrice );
	abstract List<Product> getAllProductByCategory(String productCategory);
//	abstract List<Product> getAllProductByCategory(int initialPrice, int finalPrice);


}
