package com.example.justforfun.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.justforfun.entity.Product;
import com.example.justforfun.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService service;
	
	@PostMapping("/addproduct")
	public String addProduct(Product product) {
		return service.addProduct(product);
	}
	@PutMapping("/updateproduct")
	public String updateProduct(Product product) {
		return service.updateProduct(product);
	}
	@DeleteMapping("/deleteproduct")
	public String deleteProduct(int productId) {
		return service.deleteProduct(productId);
	}
	@GetMapping("/getproduct/{id}")
	public Product getProductById(int productId) {
		return service.getProductById(productId);
	}
	@GetMapping("/getproducts")
	public List<Product> getAllProducts(){
		return service.getAllProducts();
	}
	@GetMapping("/getproductsbtw/iprice/fprice")
	public List<Product> getAllProductsBetweenPrices(@PathVariable("iprice") int initialPrice,@PathVariable("fprice")int finalPrice ){
		return service.getAllProductsBetweenPrices(initialPrice, finalPrice);
	}
	@GetMapping("/getproductsbycategory/category")
	public List<Product> getAllProductByCategory(String productCategory){
		return service.getAllProductByCategory(productCategory);
	}

}
